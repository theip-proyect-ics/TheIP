
#include "Parrilla.h"
#include <fstream>
/*
Esta función realiza el backtracking para los slots y las aulas, generando la parrilla final

-slots: Cantidad de slots a generar (3 slots en 5 días = 25 slots)
-aulas: número de aulas por asignar a cada slot
-nTFGs: número total de TFGs por asignar
-listTFG: lista de TFGs
-profesores: lista de profesores
-numProfesores: El número de profesores en la BBDD
*/

Parrilla::Parrilla() {

	convocatoria = 0;
	nslots = 0;
	maxSlots = 0;
	naulas = 0;
	maxAulas = 0;
	nTFGs = 0;
	nProf = 0;
	presDias.valor = 0;
	presAulas.valor = 0;
	slotsxdia = 0;
	exito = false;

}

Parrilla::Parrilla(int convocatoria, int slotsxdia, int nslots, int naulas, int nTFGs, int nProf) {

	this->convocatoria = convocatoria;
	this->nslots = nslots * slotsxdia;
	this->maxSlots = this->nslots;
	this->slotsxdia = slotsxdia;
	this->naulas = naulas;
	this->maxAulas = naulas;
	this->nTFGs = nTFGs;
	this->nProf = nProf;
	presDias.valor = 0;
	presAulas.valor = 0;
	exito = false;
	ultslot = -1;

	presentaciones = (Presentacion**)malloc(nTFGs * sizeof(Presentacion*));

	ProfTFGs = (int**)malloc(nProf * sizeof(int*));

	for (int i = 0; i < nTFGs; i++) presentaciones[i] = NULL;
	for (int i = 0; i < nProf; i++) ProfTFGs == NULL;

	presAulas.slot = (int*)malloc(nTFGs * sizeof(int));
	presAulas.dia = (int*)malloc(nTFGs * sizeof(int));
	presAulas.aula = (int*)malloc(nTFGs * sizeof(int));

	for (int i = 0; i < nTFGs; i++) {
		presAulas.slot[i] = -1;
		presAulas.dia[i] = -1;
		presAulas.aula[i] = -1;
	}

	presAulas.jurado1 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presAulas.jurado2 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presAulas.jurado3 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));

	for (int i = 0; i < nTFGs; i++) {
		presAulas.jurado1[i] = NULL;
		presAulas.jurado2[i] = NULL;
		presAulas.jurado3[i] = NULL;
	}

	presDias.slot = (int*)malloc(nTFGs * sizeof(int));
	presDias.dia = (int*)malloc(nTFGs * sizeof(int));
	presDias.aula = (int*)malloc(nTFGs * sizeof(int));

	for (int i = 0; i < nTFGs; i++) {
		presDias.slot[i] = -1;
		presDias.dia[i] = -1;
		presDias.aula[i] = -1;
	}

	presDias.jurado1 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presDias.jurado2 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presDias.jurado3 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));

	for (int i = 0; i < nTFGs; i++) {
		presDias.jurado1[i] = NULL;
		presDias.jurado2[i] = NULL;
		presDias.jurado3[i] = NULL;
	}

}

Parrilla::~Parrilla() {
	free(presentaciones);
	free(presAulas.jurado1);
	free(presAulas.jurado2);
	free(presAulas.jurado3);
	free(presAulas.slot);
	free(presAulas.dia);
	free(presAulas.aula);
	free(presDias.jurado1);
	free(presDias.jurado2);
	free(presDias.jurado3);
	free(presDias.slot);
	free(presDias.dia);
	free(presDias.aula);
}

void Parrilla::setParrilla(int convocatoria, int slotsxdia, int nslots, int naulas, int nTFGs, int nProf) {
	this->convocatoria = convocatoria;
	this->nslots = nslots * slotsxdia;
	this->maxSlots = this->nslots;
	this->slotsxdia = slotsxdia;
	this->naulas = naulas;
	this->maxAulas = naulas;
	this->nTFGs = nTFGs;
	this->nProf = nProf;
	presDias.valor = 0;
	presAulas.valor = 0;
	exito = false;
	ultslot = -1;

	presentaciones = (Presentacion**)malloc(nTFGs * sizeof(Presentacion*));

	ProfTFGs = (int**)malloc(nProf * sizeof(int*));

	for (int i = 0; i < nTFGs; i++) presentaciones[i] = NULL;
	for (int i = 0; i < nProf; i++) ProfTFGs == NULL;

	presAulas.slot = (int*)malloc(nTFGs * sizeof(int));
	presAulas.dia = (int*)malloc(nTFGs * sizeof(int));
	presAulas.aula = (int*)malloc(nTFGs * sizeof(int));

	for (int i = 0; i < nTFGs; i++) {
		presAulas.slot[i] = -1;
		presAulas.dia[i] = -1;
		presAulas.aula[i] = -1;
	}

	presAulas.jurado1 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presAulas.jurado2 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presAulas.jurado3 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));

	for (int i = 0; i < nTFGs; i++) {
		presAulas.jurado1[i] = NULL;
		presAulas.jurado2[i] = NULL;
		presAulas.jurado3[i] = NULL;
	}

	presDias.slot = (int*)malloc(nTFGs * sizeof(int));
	presDias.dia = (int*)malloc(nTFGs * sizeof(int));
	presDias.aula = (int*)malloc(nTFGs * sizeof(int));

	for (int i = 0; i < nTFGs; i++) {
		presDias.slot[i] = -1;
		presDias.dia[i] = -1;
		presDias.aula[i] = -1;
	}

	presDias.jurado1 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presDias.jurado2 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));
	presDias.jurado3 = (Profesor**)malloc(nTFGs * sizeof(Profesor*));

	for (int i = 0; i < nTFGs; i++) {
		presDias.jurado1[i] = NULL;
		presDias.jurado2[i] = NULL;
		presDias.jurado3[i] = NULL;
	}

}

void Parrilla::generarParrilla(TFG **listTFG, Profesor **profesores) {

	cout << "generando parrilla" << endl;

	bitAulas = (int*)malloc(nslots * sizeof(int));
	bitProf = (short**)malloc(nProf * sizeof(short*));

	for (int i = 0; i < nProf; i++) {
		bitProf[i] = (short*)malloc(nProf * sizeof(short));
	}

	exito = true;

	for (int i = 0; i < nProf; i++) {

		ProfTFGs[i] = (int*)malloc(profesores[i]->getNGrados() * sizeof(int));

		for (int j = 0; j < profesores[i]->getNGrados(); j++) {
			ProfTFGs[i][j] = profesores[i]->getNumTFGs(j);
		}
	}

	Aulasinit = naulas;
	Slotsinit = nslots;
	bool paso = true;
	int cont = 0;

	while (nslots > (slotsxdia*2) && exito == true) {

		//cout << "Nuevo algoritmo" << endl;

		ultslot = -1;
		maxSlots = nslots;
		exito = false;	

		for (int i = 0; i < nslots; i++) bitAulas[i] = 0;

		for (int i = 0; i < nProf; i++)
			for (int j = 0; j < nslots; j++) bitProf[i][j] = 0; // Si el bit está a 0, no está asignado. Cuando un TFG se asigne, se pondrá a 1

		for (int i = 0; i < nProf; i++) {
			for (int j = 0; j < profesores[i]->getNGrados(); j++)
				ProfTFGs[i][j] = profesores[i]->getNumTFGs(j);
		}

		generarPresentacion(listTFG, 0, profesores);
		if(paso) naulas--;
		else nslots -= slotsxdia;

		if (paso && naulas == 0) {
			naulas = Aulasinit;
			nslots -= slotsxdia;
			paso = false;
		}
		

		if (presDias.slot[0] != -1) cont++;

		//cout << "PARRILLA CREADA CORRECTAMENTE <<<<<<<<" << naulas << " - " << nslots << "<<<<<<<<<" << endl;

	}

	if (presDias.slot[0] != -1) cout << "Se han encontrado " << cont << " parrillas diferentes" << endl;
	else {
		cout << "Lo sentimos, no existe ninguna combinacion posible" << endl;
		return;
	}

	nslots = Slotsinit;
	cout << "-------------------------------------" << endl << "Mejor algoritmo con menos aulas posibles:";
	cout << endl << "-------------------------------------" << endl;



	for (int i = 0; i < nTFGs; i++) {

		cout  << "Presentacion " << i << ":" << endl;

		cout << "Dia: " << presAulas.dia[i] + 1 << ", slot: " << presAulas.slot[i] << ", aula: " << presAulas.aula[i] + 1 << endl;
		cout << "   jurado 1: " << presAulas.jurado1[i]->getNombre() << endl;
		cout << "   jurado 2: " << presAulas.jurado2[i]->getNombre() << endl;
		cout << "   jurado 3: " << presAulas.jurado3[i]->getNombre() << endl << endl;

	}

	cout << "-------------------------------------" << endl << endl;

	cout << "-------------------------------------" << endl << "Mejor algoritmo con menos dias posibles:";
	cout << endl << "-------------------------------------" << endl;


	for (int i = 0; i < nTFGs; i++) {

		cout << "Presentacion " << i << ":" << endl;

		cout << "Dia: " << presDias.dia[i] + 1 << ", slot: " << presDias.slot[i] << ", aula: " << presDias.aula[i] + 1 << endl;
		cout << "   jurado 1: " << presDias.jurado1[i]->getNombre() << endl;
		cout << "   jurado 2: " << presDias.jurado2[i]->getNombre() << endl;
		cout << "   jurado 3: " << presDias.jurado3[i]->getNombre() << endl << endl;

	}
//	printf("He llegado aqui");

	cout << "-------------------------------------" << endl << endl;
	

	char menu = 'N';

	cout << "Desea exportar las parrillas? (S/N)" << endl;

	cin >> menu;

	if (menu == 'S' || menu == 's' || menu == 'Y' || menu == 'y') {

		cout << "Cual de ellas?\n"
			"Minimizando el numero de Dias (D), \n"
			"Minimizando el numero de aulas (A), \n"
			"Las dos (T)" << endl;
		cin >> menu;

		if (menu == 'D' || menu == 'd') {

			ofstream exportacion;
			exportacion.open("exportacion.txt");

			for (int i = 0; i < nTFGs; i++) {
				exportacion << "Presentacion " << i << ":" << endl;

				exportacion << "Dia: " << presDias.dia[i] + 1 << ", slot: " << presDias.slot[i] << ", aula: " << presDias.aula[i] + 1 << endl;
				exportacion << "   jurado 1: " << presDias.jurado1[i]->getNombre() << endl;
				exportacion << "   jurado 2: " << presDias.jurado2[i]->getNombre() << endl;
				exportacion << "   jurado 3: " << presDias.jurado3[i]->getNombre() << endl << endl;
			}

			exportacion << "--------------------------------------\n";
			exportacion.close();

		}
		if (menu == 'A' || menu == 'a') {

			ofstream exportacion;
			exportacion.open("exportacion.txt");

			for (int i = 0; i < nTFGs; i++) {
				exportacion << "Presentacion " << i << ":" << endl;

				exportacion << "Dia: " << presAulas.dia[i] + 1 << ", slot: " << presAulas.slot[i] << ", aula: " << presAulas.aula[i] + 1 << endl;
				exportacion << "   jurado 1: " << presAulas.jurado1[i]->getNombre() << endl;
				exportacion << "   jurado 2: " << presAulas.jurado2[i]->getNombre() << endl;
				exportacion << "   jurado 3: " << presAulas.jurado3[i]->getNombre() << endl << endl;
			}

			exportacion << "--------------------------------------\n";
			exportacion.close();
		}

		if (menu == 'T' || menu == 't') {
			printf("Exportando T\n");
			ofstream exportacion;
			exportacion.open("exportacion.txt");
			ofstream exportacion2;
			exportacion.open("exportacion2.txt");

			for (int i = 0; i < nTFGs; i++) {
				exportacion << "Presentacion " << i << ":" << endl;

				exportacion << "Dia: " << presDias.dia[i] + 1 << ", slot: " << presDias.slot[i] << ", aula: " << presDias.aula[i] + 1 << endl;
				exportacion << "   jurado 1: " << presDias.jurado1[i]->getNombre() << endl;
				exportacion << "   jurado 2: " << presDias.jurado2[i]->getNombre() << endl;
				exportacion << "   jurado 3: " << presDias.jurado3[i]->getNombre() << endl << endl;

				exportacion2 << "Presentacion " << i << ":" << endl;

				exportacion2 << "Dia: " << presAulas.dia[i] + 1 << ", slot: " << presAulas.slot[i] << ", aula: " << presAulas.aula[i] + 1 << endl;
				exportacion2 << "   jurado 1: " << presAulas.jurado1[i]->getNombre() << endl;
				exportacion2 << "   jurado 2: " << presAulas.jurado2[i]->getNombre() << endl;
				exportacion2 << "   jurado 3: " << presAulas.jurado3[i]->getNombre() << endl << endl;
			}
			exportacion << "--------------------------------------\n";
			exportacion.close();
			exportacion2 << "--------------------------------------\n";
			exportacion2.close();
		}
	}
	return;
}

/*
Esta función realiza el backtracking para los TFGs

-slot: el slot para el TFG
-aulas: número de aulas por asignar a este slot
-naula: numero de aulas con TFG asignado a este slot
-listTFG: lista de TFGs
-profesores: lista de profesores
-presentaciones: lista de presentaciones generada
-bitmap: bitmap de TFGs asignados
*/

void Parrilla::generarPresentacion(TFG **listTFG, int TFG, Profesor **profesores) {

	if (nTFGs == TFG) {
		exito = true;
		valorarParrilla();
		maxSlots = ultslot + 1;
		maxSlots++;

		return;
	}


	for (int slot = 0; slot < nslots; slot++) {

		if (bitAulas[slot] == naulas) {
			//cout << "No quedan aulas" << endl;
			continue;
		}

		int* jurado = (int*)malloc(4 * sizeof(int));
		for (int i = 1; i < 4; i++) jurado[i] = -1;
		jurado[0] = 0;				// jurado[0] te indica cuántos profesores lleva

		generarTribunal(slot, listTFG, TFG, profesores, jurado); //generamos un tribunal para la presentación

		if (exito) return;
		else free(jurado);
		//listTFG[TFG].eliminarPresentacion();
	}

	//cout << "vuelta atras de TFG de TFG " << TFG << endl;
	//generarPresentacion(listTFG, TFG, profesores);
	return;
}


void Parrilla::generarTribunal(int slot, TFG **listTFG, int TFG, Profesor **profesores, int *jurado) {

	if (jurado[0] == 3) {

		listTFG[TFG]->crearPresentacion(slot / slotsxdia, bitAulas[slot], slot % slotsxdia, 0);		// Crea la presentación, el 0 es de Convocatoria
		Presentacion *aux = listTFG[TFG]->getPresentacion();

		for (int i = 1; i < 4; i++)
			aux->addJurado(profesores[jurado[i]], i - 1);

		bitAulas[slot]++;

		presentaciones[TFG] = aux;		// Guardar la presentación en la parrilla

		// Mirar aquí si el tutor puede;
		//if (listTFG[TFG]->getTutor()->getDisponibilidad()->getDisponibilidad(slot / SLOTS, slot))
			//aux->addJurado(listTFG[TFG]->getTutor());

		//free(jurado);

		generarPresentacion(listTFG, TFG + 1, profesores);

		if (!exito) {

			listTFG[TFG]->eliminarPresentacion();
			
			presentaciones[TFG] = NULL;

			bitAulas[slot]--;

		}
		return;
	}

	int profesor = 0;
	if (jurado[0] > 1) profesor = jurado[jurado[0]] + 1;	// Elimina variaciones por orden

	int* grados;
	bool aux;
	int gradTFG;

	for (profesor; profesor < nProf; profesor++) {

		//cout << "mirando profesor " << profesor << endl;

		grados = profesores[profesor]->getGrados(); // Recibir los grados del profesor;
		aux = false;
		gradTFG = listTFG[TFG]->getGrado();

		for (int i = 0; i < profesores[profesor]->getNGrados(); i++) {
			//cout << grados[i] << " - ";
			if (gradTFG == grados[i]) {
				aux = true;
				break;
			}
		}

		if (!aux) {
			//cout << "No está en el grado" << endl;
			continue;
		}

	
		//cout << "paso 1 - " << slot / slotsxdia << " - " << slot % slotsxdia << endl;

		if (!profesores[profesor]->getDisponibilidad()->getDisponibilidad(slot / slotsxdia, slot % slotsxdia)) {
			//cout << "No esta disponible" << endl;
			continue;
		}

		if (bitProf[profesor][slot] == 1) {
			//cout << "Ya esta elegido" << endl;
			continue;
		}

		if (ProfTFGs[profesor][gradTFG] <= 0) {
			//cout << "No le quedan jurados" << endl; 
			continue;
		}

		if (jurado[0] == 0 && !profesores[profesor]->getDoctorado()) {
			//cout << "No es doctor" << endl;
			continue;
		}

		if (jurado[0] == 1 && profesor < jurado[1] && profesores[profesor]->getDoctorado()) continue;	// Elimina variaciones por orden

		jurado[0]++;
		jurado[jurado[0]] = profesor;
		bitProf[profesor][slot] = 1;
		ProfTFGs[profesor][gradTFG]--;

		generarTribunal(slot, listTFG, TFG, profesores, jurado); //generamos un tribunal para la presentación

		if (exito) return;
		else {

			jurado[jurado[0]] = -1;
			jurado[0]--;
			bitProf[profesor][slot] = 0;
			ProfTFGs[profesor][gradTFG]++;
		}
	}

	return;
}

int Parrilla::valorarParrilla() {
	
	int valor = 0;
	int aulasUt = 0;
	unsigned int diasExtra = 0;
	unsigned int aulasExtra = 0;
	unsigned int tutores = 0;

	// Ahorrar Días

	for (int i = Slotsinit - 1; i >= 0; i--) {
		if (bitAulas[i] > 0) break;

		if (i % slotsxdia == 0) diasExtra++;
	}

	for (int i = Slotsinit - 1; i >= 0; i--)
		if (aulasUt < bitAulas[i]) aulasUt = bitAulas[i];

	aulasExtra = Aulasinit - aulasUt;

	for (int i = 0; i < nTFGs; i++)
		if (presentaciones[i]->GetJurado(3) != NULL) tutores++;

	valor = diasExtra * 8 + aulasExtra * 2 + tutores;

	if (valor > presDias.valor) {
		for (int i = 0; i < nTFGs; i++) {
			presDias.slot[i] = presentaciones[i]->getSlot();
			presDias.dia[i] = presentaciones[i]->getDia();
			presDias.aula[i] = presentaciones[i]->getAula();

			presDias.jurado1[i] = presentaciones[i]->GetJurado(0);
			presDias.jurado2[i] = presentaciones[i]->GetJurado(1);
			presDias.jurado3[i] = presentaciones[i]->GetJurado(2);
		}
		presDias.valor = valor;
	}

	valor = diasExtra * 2 + aulasExtra * 8 + tutores;

	if (valor > presAulas.valor) {
		for (int i = 0; i < nTFGs; i++) {
			presAulas.slot[i] = presentaciones[i]->getSlot();
			presAulas.dia[i] = presentaciones[i]->getDia();
			presAulas.aula[i] = presentaciones[i]->getAula();

			presAulas.jurado1[i] = presentaciones[i]->GetJurado(0);
			presAulas.jurado2[i] = presentaciones[i]->GetJurado(1);
			presAulas.jurado3[i] = presentaciones[i]->GetJurado(2);
		}
		presAulas.valor = valor;
	}
	return 0;
}

ParrillaAux* Parrilla::getAux(int fich) {
	if (fich == 1) return &presDias;
	else &presAulas;
}

int Parrilla::exportarParrilla(int parrillas) {

	ParrillaAux* par;

	if (parrillas == 1) par = &presDias;
	else par = &presAulas;

	std::string salida, temp;
	char const *pchar = NULL;

	cout << "paso 1" << endl;

	//exec(system("dir"));

	cout << "paso 2" << endl;

	if (parrillas == 1) { system("start echo \"Presentacion\",\"Dia\",\"Aula\",\"Slot\",\"Jurado1\",\"Jurado2\",\"Jurado3\" > ParrillaAulas.csv"); }
	else if (parrillas == 2) { system("start echo \"Presentacion\",\"Dia\",\"Aula\",\"Slot\",\"Jurado1\",\"Jurado2\",\"Jurado3\" > ParrillaDias.csv"); }

	for (int i = 0; i < nTFGs; i++)
	{
		salida = "echo \"";
		salida += to_string(i + 1); // Presentacion
		salida += "\",\"";
		temp = to_string(par->dia[i]); // Dia
		salida += temp;
		salida += "\",\"";
		temp = to_string(par->aula[i]); // Aula
		salida += temp;
		salida += "\",\"";
		temp = to_string(par->aula[i]); // Slot
		salida += temp;
		salida += "\",\"";
		temp = par->jurado1[i]->getNombre();
		salida += temp;
		salida += "\",\"";
		temp = par->jurado2[i]->getNombre();
		salida += temp;
		salida += "\",\"";
		temp = par->jurado3[i]->getNombre();
		salida += temp;
		if(parrillas == 1) salida += "\" >> ParrillaAulas.csv";
		if (parrillas == 2) salida += "\" >> ParrillaDias.csv";

		pchar = salida.c_str();
		system(pchar);
	}

	return 1;
}